def ftoc(f)
    subtracted = f-32
    subtracted * 5/9
end

def ctof(c)
    c = c.to_f
    if c == 0.0
        return 32
    end
   divided = c*9/5
   final = divided + 32
   final
end