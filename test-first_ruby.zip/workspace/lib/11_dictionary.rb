class Dictionary
    attr_reader :entries
    def initialize
        @entries = {}
    end
    
    def add(entry)
        @entries.merge!(entry) unless entry.is_a? String
        @entries[entry] = nil unless entry.is_a? Hash
    end
    
    def keywords
        @entries.keys.sort    
    end
    
    def include?(entry)
        @entries.keys.include?(entry)
    end
    
    def find(key)
        matches = {}
        if entries.size > 0
            matches = entries.select {|k, v| k.include? key}
        else
            {}
        end
    end
    
    def printable
        @entries.to_a.sort.map{|k,v| "[#{k}] \"#{v}\""}.join("\n")
    end
end
