class Array
    def sum
        @sum = 0
        if self.empty?
            @sum
        else
            self.each {|x| @sum+=x}
            @sum
        end
    end
    
    def square
        @square = []
        if self.empty?
            @square
        else
            @square = self.map {|x| x**2}
        end 
    end
    
    def square!
        if self.empty?
            self
        else
            self.map! {|x| x**2}
        end 
    end
end