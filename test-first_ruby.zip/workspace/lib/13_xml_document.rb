class XmlDocument
  #NOT REQUIRED
end
