class Friend
  # TODO: your code goes here!
  def greeting(who = nil)
    str = "Hello"
    if who.nil?
        str << "!"
    else
        str << ", " << who << "!"
    end
  end
end
