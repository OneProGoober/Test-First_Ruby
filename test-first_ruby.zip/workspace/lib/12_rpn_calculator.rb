class RPNCalculator
    $operand1 = 0
    $operand2 = 0
    def initialize
       @stack = [] 
    end
    
    def push(num)
        @stack.push(num)
    end
    
    def grabOperands
        if @stack.last(2).first != nil
            $operand1 = @stack.pop
            $operand2 = @stack.pop
        else
            "error"
        end
    end
    
    def plus
        if grabOperands != "error"
            @stack.push($operand1 + $operand2)
        else
            raise "calculator is empty"
        end
    end
    
    def minus
        if grabOperands != "error"
            @stack.push($operand2 - $operand1)
        else
            raise "calculator is empty"
        end
    end
    
    def divide
        if grabOperands != "error"
            @stack.push($operand2 / $operand1.to_f)
        else
            raise "calculator is empty"
        end
    end
    
    def times
        if grabOperands != "error"
            @stack.push($operand2 * $operand1)
        else
            raise "calculator is empty"
        end
    end
    
    def tokens(string)
        tokens = string.split(" ")
        tokens.map! do |val|
            case val
                when "*"
                    val.to_sym
                when "/"
                    val.to_sym
                when "+"
                    val.to_sym
                when "-"
                    val.to_sym
                else
                    val.to_i
            end
        end
        tokens
    end
    
    def evaluate(string)
        tokens(string).each do |val|
            case val
                when :*
                    times
                when :/
                    divide
                when :+
                    plus                    
                when :-
                    minus
                else
                    push(val)
            end
        end
        value
    end
    
    def value
        @stack.last
    end
end
