class Temperature
  def initialize(options = {})
    @c, @f = options[:c], options[:f]
    @c = ((@f - 32) * 5) / 9 unless @f.nil?
    @f = ((@c.to_f * 9.0) / 5.0) + 32.0 unless @c.nil?
  end
  
  def in_celsius
    @c
  end
  
  def in_fahrenheit
    @f
  end
  
  def Temperature.from_celsius(t)
    Temperature.new(:c => t)
  end
  
  def Temperature.from_fahrenheit(t)
    Temperature.new(:f => t)
  end
end

class Fahrenheit < Temperature
  def initialize(t)
    super(:f => t)
  end
end

class Celsius < Temperature
  def initialize(t)
    super(:c => t)
  end
end