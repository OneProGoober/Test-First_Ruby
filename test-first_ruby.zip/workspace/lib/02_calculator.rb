def add(num1, num2)
    num1 +num2
end

def subtract(num1, num2)
    num1-num2
end

def sum(arr)
    sum = 0
  arr.each do |x|
    sum += x
  end
  sum
end

def multiply(num1, nums)
    nums.each_index do |idx|
        num1*= nums[idx]
    end
    num1
end

def power(num1, num2)
    num1**num2
end

def factorial(num)
    total = 1
   while num >=1
        total *=num
        num -= 1
   end
   total
end