def echo(string)
    string
end

def shout(string)
    string.upcase
end

def repeat(string, count = 2)
   ((string +" ") * count).strip
end

def start_of_word(string, index)
    char = string.split("")
    start = ""
    char.each_with_index { |c, i|
        if i < index
        start += c
        end
    }
    start
end

def first_word(string)
    string.split(" ")[0]
end

def titleize(string)
    arr = string.split(" ")
    words = ["and", "over", "the"]
    finalString = []
    arr.each_with_index do |word, index|
        words.include?(word) && index > 0 ? finalString << word : finalString << word.capitalize
    end
finalString.join(" ")
end