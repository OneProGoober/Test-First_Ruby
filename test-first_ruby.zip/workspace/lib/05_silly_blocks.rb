def reverser
   arr = yield.split(" ")
   reversed = []
   arr.each do |word|
       reversed << word.reverse
   end
   reversed.join(" ")
end

def adder(n = 1)
    num = yield
    num + n
end

def repeater(num = 1)
    num.times {yield} 
end