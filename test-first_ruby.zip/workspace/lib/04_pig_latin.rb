def translate(string)
    stringArray = string.split(" ")
    final = []
    wordLength = 0
    vowels = ["a", "e", "i", "o", "u"]
    stringArray.each do |word|
        caps = false;
        if(word == word.capitalize)
           caps = true
           word.downcase!
        end
        wordLength = word.length
        if vowels.include?(word[0])
            word = word + "ay"
        elsif (!vowels.include?(word[1])) && !(vowels.include?(word[2])) #first 3 letters are consonants
            word = word[3..(wordLength - 1)] + word[0..2] + "ay"
        elsif !vowels.include?(word[1]) #first 2 letters are consonants
            if  word[2] != "u"
                word = word[2..wordLength-1] + word[0..1] + "ay" 
            else
                word = word[3..wordLength-1] + word[0..2] + "ay" #account for the qu phoneme with a preceding consonant
            end
        elsif (word.index("qu") != nil) #make sure we have a qu phoneme and then move it to the end
                idx = word.index('qu')
    			word = word[idx + 2 .. word.length - 1] + word[0 .. (idx + 1)] + 'ay' 
    	else
    		word = word[1..wordLength-1] + word[0] + "ay"
    	end
    	if (caps)
    	    word.capitalize!
    	end
    	final << word
    end
    final.join(" ")
end