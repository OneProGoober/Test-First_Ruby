class Book
   #setter
   def title=(title)
    words = title.split(" ")
    words[0].capitalize!
    words.collect! { |word|
      if ["and","in","the","of", "a", "an"].include? word
        word
      else
        word.capitalize
      end
    }
    @title = words.join(" ")
  end
  
  #getter
  def title
    @title
  end
end
